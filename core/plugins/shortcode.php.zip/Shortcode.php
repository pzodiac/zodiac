<?php
namespace Plugins;

use Commons\Curl;
use Phalcon\Mvc\View\Simple;

require __DIR__ . '/WP/formatting.php';
require __DIR__ . '/WP/shortcodes.php';

class Shortcode

{
    function __construct($controller)
    {
        add_shortcode("ads_item", function($atts, $content) use ($controller){


            if (isset($atts['hash_id'])) {
               $url = "https://api.muabannhanh.com/article/detail?&is_count=0&session_token=cb2663ce82a9f4ba448ba435091e27bb&hash_id={$atts['hash_id']}";
            } else if (isset($atts['id'])) {
               $url = "https://api.muabannhanh.com/article/detail?&is_count=0&session_token=cb2663ce82a9f4ba448ba435091e27bb&id={$atts['id']}";
            }

            if (isset($url)) {
                $cacheName = md5($url);
                $article = $controller->cache->get($cacheName);
                if (!$article) {
                    $article = Curl::curlGet($url);

                    if (!empty($article)) {
                        $article = json_decode($article, true);
                        if (isset($article['result'])) {
                            $controller->cache->save($cacheName, $article['result']);
                            $article = $article['result'];
                        }


                    }
                }

                $view = new Simple();
                $view->setViewsDir(__DIR__);
                $view->article = $article;
                $view->render( "/WP/view/ads_item");

                return $view->getContent();
            }

            return '';

        });
    }



    function do_shortcode($content)
    {
        return do_shortcode($content);
    }
}